import { BookingSpot } from './booking-spot';

describe('BookingSpot', () => {
  it('should create an instance', () => {
    expect(new BookingSpot()).toBeTruthy();
  });
});
